<?php $__env->startSection('content'); ?>
<div class="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 mx-4 my-2">
  <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card w-full bg-base-100 shadow-xl">
    <figure><img class="object-cover h-48 w-full" src="<?php echo e($r['image']); ?>" alt="Shoes" /></figure>
    <div class="card-body">
      <h2 class="card-title"><?php echo e($r['title']); ?></h2>
      <p><?php echo e(strlen($r['description']) > 100 ? substr($r['description'], 0, 100).'....' : $r['description']); ?></p>
      <div class="card-actions justify-end">
        <a href="<?php echo e($r['url']); ?>" target="_blank" class="btn btn-primary">Read more</a>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yuda\OneDrive\Desktop\capstone-sib3\resources\views/article/index.blade.php ENDPATH**/ ?>